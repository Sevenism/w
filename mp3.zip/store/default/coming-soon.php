<?php
$json_string = 'https://rss.itunes.apple.com/api/v1/id/apple-music/coming-soon/all/100/explicit.json';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
$comingsoon = "";
foreach ($obj['feed']['results'] as $result) {
//echo $result['name'] . '<br>' . PHP_EOL;
$comingsoon = $comingsoon . $result['name'] . "\n";
}
file_put_contents('store\default\keywords\4.txt', $comingsoon);
?>