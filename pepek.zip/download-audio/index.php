<?php
$dir = '/lagu/';
$url=$_SERVER['REQUEST_URI'];
$username=str_replace('/download-audio/?', '', $_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<HTML>
<head>
<meta charset="utf-8"/>
<meta content="IE=edge" http-equiv="X-UA-Compatible"/>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<title>Download Lagu</title>
<meta name="robots" content="noindex, nofollow"/>
</head>
<body>
<center><h2><a href="http://www.madrasvegetarian.com">Download Lagu</a></h2></center>
<p style="text-align:center;font-size:14px;font-style:italic;color:red;font-weight:bold;">&darr;&darr;&darr;&darr;&darr;&darr;&darr;&darr;&darr;&darr;<br /><br /> <iframe src="https://y-api.org/button-api/?v=<?php echo $username; ?>" FRAMEBORDER="0" MARGINWIDTH="0" MARGINHEIGHT="0" SCROLLING="no" WIDTH="300" HEIGHT="40"></iframe> <br />
<iframe src="https://mp3api.genyt.com/?id=<?php echo $username; ?>" FRAMEBORDER="0" MARGINWIDTH="0" MARGINHEIGHT="0" SCROLLING="no" style="width: 300px;height: 50px;"><br/></iframe>
<br/>
<br />&uarr;&uarr;&uarr;&uarr;&uarr;&uarr;&uarr;&uarr;&uarr;&uarr;</p>
</body>
</HTML>
