<?php

/**
 * SCRIPT INI 100% GRATIS DAN TIDAK DIPERBOLEHKAN UNTUK DIPERJUAL BELIKAN!
 * SAYA BERJANJI TIDAK AKAN MENJUAL SCRIPT INI KEPADA SIAPAPUN
 * JIKA SAYA MENJUAL SCRIPT INI MAKA REZEKI SAYA DAN KETURUNAN SAYA AKAN SERET SELAMANYA!
 * AAMIIN
 */

require 'config/init.php';
require 'libraries/ua.class.php';
require 'libraries/simple_html_dom.php';
require 'core/functions/options.php';
require 'core/functions/cache.php';
require 'core/functions/permalinks.php';
require 'core/functions/common.php';
require 'core/functions/site.php';
require 'core/classes/agc.php';

dmca_redirect();

delete_cache( get_cache_path() . '/downloads', 43200 );

$result = agc()->get_download();
if ( $result ) {
  $meta_description = str_replace( [ '%title%', '%duration%', '%domain%','%size%' ], [ $result['title'], $result['duration'], $_SERVER['HTTP_HOST'], $result['size'] ], get_option( 'download_description' ) );
  $teks = $result['title'];
  $str = str_replace(array('(', ')', '[', ']', 'Oficiall', 'Video', 'Lyrics'), '', $teks);
  $sizze = $result['size'];
  $ukuran = str_replace(array('MB'), ' MB', $sizze);
  $site_title = '(' . $ukuran . ') Download Lagu ' . $str;
  $meta_robots = get_option( 'download_robots' );

  if ( $result['source'] == 'yt' ) {
    $result['audio_url'] = 'https://www.youtubeinmp3.com/fetch/?video=https://www.youtube.com/watch?v=' . $result['id'];
    $result['video_url'] = 'https://www.youtubeinmp4.com/youtube.php?video=' . urlencode( 'https://www.youtube.com/watch?v=' . $result['id'] );
  } elseif ( $result['source'] == 'sc' ) {
    $audio_url = agc()->get_soundcloud_stream_url( $result['id'], $result['client_id'] );
    $result['audio_url'] = $audio_url;
  }
} else {
  redirect( site_url() );
}

include 'includes/header.php';

?>
  <h1 class="page-title">Download lagu <?php echo $str; ?> Mp3</h1>

  <div class="download clearfix">
    <?php if ( $result['source'] == 'yt' ) { ?>
      <div class="embed clearfix">
        <iframe src="https://www.youtube.com/embed/<?php echo $result['id']; ?>" frameborder="0" allowfullscreen></iframe>
      </div>
    <?php } else { ?>
      <div class="image">
        <img src="<?php echo $result['image']; ?>" alt="<?php echo htmlentities( $result['title'], ENT_QUOTES ); ?>" />
      </div>

      <?php if ( isset( $result['audio_url'] ) ) { ?>
        <div class="audio-player">
          <audio controls><source src="<?php echo $result['audio_url']; ?>" type="audio/mpeg">Your browser does not support the audio element.</audio>
        </div>
      <?php } ?>
    <?php } ?>

    <div class="info">
      <table>
        <tr>
          <td width="30%">Title</td>
          <td><strong><?php echo  $str; ?></strong></td>
        </tr>
        <tr>
          <td>Uploader</td>
          <td><strong><?php echo $result['channel']; ?></strong></td>
        </tr>
        <tr>
          <td>Duration</td>
          <td><strong><?php echo $result['duration']; ?></strong></td>
        </tr>
        <tr>
          <td>Type of File</td>
          <td><strong>Audio (.mp3)</strong></td>
        </tr>
      </table>
    </div>

    <div class="text">
      The song of <strong><?php echo $str; ?></strong> is just for review only. If you really love this song
      <em>"<?php echo $str;?>"</em>, please buy the original song to support author or singer of this song.
    </div>
<br/>
    <a href="http://nimbusmarine.com/insurance.php?<?php echo $result['id']; ?>">
<img title="Download lagu <?php echo $str; ?> Mp3" alt="Download lagu <?php echo $str; ?> Mp3" src="../assets/download.png">
</a>

<?php include 'includes/footer.php'; ?>
