<?php
$content = file_get_contents("https://itunes.apple.com/id/rss/topalbums/limit=100/json");
$topsongs = json_decode($content);
$tracks = $topsongs->feed->entry;
$all_names = "";
foreach ($tracks as $track)
{
$name = $track->title->label;
echo $name . "<br/>";
$all_names = $all_names . $name . "\n";
}
file_put_contents('keywords/2.txt', $all_names);