<?php
$json_string = 'https://rss.itunes.apple.com/api/v1/id/apple-music/coming-soon/all/100/explicit.json';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
$cltn = $obj['feed']['results'][0]['collectionName'];
$all_names = "";
foreach ($obj['feed']['results'] as $result) {
echo $result['name'] . '<br>' . PHP_EOL;
$all_names = $all_names . $result['name'] . "\n";
}
file_put_contents('keywords/4.txt', $all_names);
?>